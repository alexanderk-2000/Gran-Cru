
export type Category = 'Genuss' | 'Investment' | 'Rarität' | 'Daily Drinker';
export type WineType = 'Rot' | 'Weiß' | 'Rosé' | 'Schaumwein' | 'Süßwein';
export type BottleFormat = '0.375L' | '0.75L' | '1.5L (Magnum)' | '3.0L (Double Magnum)' | '6.0L (Imperial)';
export type RepeatRule = 'none' | 'daily' | 'weekly' | 'monthly' | 'yearly';
export type InstanceStatus = 'planned' | 'consumed' | 'skipped';
export type DrinkArchetype = 'EARLY' | 'CLASSIC' | 'LONG_LIVED' | 'SWEET';

export interface Occasion {
  id: string;
  user_id: string;
  title: string;
  start_date: string; 
  end_date: string;
  repeat_rule: RepeatRule;
  repeat_interval: number;
  created_at: string;
}

export interface OccasionInstance {
  id: string;
  occasion_id: string;
  user_id: string;
  instance_date: string;
  wine_id: string | null;
  status: InstanceStatus;
  note?: string;
  created_at: string;
  updated_at: string;
  occasion?: Occasion;
}

export interface UserProfile {
  id: string;
  email: string;
  currency: string;
  target_date: string;
}

export interface CriticScore {
  critic: string;
  score: string | number;
  year?: number;
}

export interface WineStructure {
  acidity?: number;
  tannin?: number;
  body?: number;
  sweetness?: number;
  oak?: number;
}

export interface Wine {
  id: string;
  user_id: string;
  name: string;
  vintage: number;
  region: string;
  category: Category;
  wine_type?: WineType;
  quantity: number;
  purchase_price: number;
  market_price?: number;
  format: BottleFormat;
  drink_start: number;
  drink_end: number;
  peak_year?: number;
  producer?: string;
  appellation?: string;
  subregion?: string;
  vineyard?: string;
  country?: string;
  alcohol_percent?: number;
  aromas?: { tag: string; intensity?: number }[];
  structure?: WineStructure;
  pairings?: { item: string; category?: string; note?: string }[];
  scores?: CriticScore[];
  confidence?: 'high' | 'medium' | 'low';
  missing_fields?: string[];
  is_favorite?: boolean;
  wishlist: boolean;
  drink_archetype?: DrinkArchetype;
  grapes?: { name: string; percentage?: number }[];
  maturation_profile?: string;
  fermentation?: string;
  aging_process?: string;
  farming?: string;
  closure_type?: string;
  deleted_reason?: string;
  created_at: string;
  updated_at: string;
  deleted_at?: string | null;
}

export enum WineStatus {
  READY = 'READY',
  HOLD = 'HOLD',
  PAST_PEAK = 'PAST_PEAK'
}

export interface Tasting {
  id: string;
  wine_id: string;
  user_id: string;
  date: string;
  rating: number;
  note: string;
}

export interface PortfolioStats {
  totalBottles: number;
  totalValue: number;
  readyCount: number;
  holdCount: number;
  pastPeakCount: number;
  averageAge: number;
  investmentValue: number;
}
