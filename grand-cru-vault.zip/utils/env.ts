
export const getApiKey = () => {
  // Directly access process.env.API_KEY as per guidelines
  try {
    if (typeof process !== 'undefined' && process.env && process.env.API_KEY) {
      return process.env.API_KEY;
    }
  } catch (e) {
    console.warn("Error accessing process.env.API_KEY");
  }
  return '';
};
