
import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Wine as WineIcon, 
  Clock, 
  Heart, 
  Menu, 
  X, 
  CircleDot, 
  ChevronRight,
  CalendarDays,
  ShieldCheck,
  LogOut,
  Sparkles,
  Trash2
} from 'lucide-react';
import { storageService } from '../services/storage.ts';
import { UserProfile } from '../types.ts';

const navItems = [
  { path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { path: '/inventory', label: 'Keller', icon: WineIcon },
  { path: '/genussplan', label: 'Anlässe', icon: CalendarDays },
  { path: '/timeline', label: 'Zeitachse', icon: Clock },
  { path: '/wishlist', label: 'Wunschliste', icon: Heart },
  { path: '/trash', label: 'Papierkorb', icon: Trash2 },
];

export const Layout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const location = useLocation();

  useEffect(() => {
    const fetchUser = async () => {
      const currentUser = await storageService.getCurrentUser();
      setUser(currentUser);
    };
    fetchUser();
  }, []);

  const handleLogout = () => {
    storageService.logout();
  };

  const isGuest = user?.email === 'Gast-Sammler';

  return (
    <div className="min-h-screen bg-alabaster flex flex-col text-charcoal">
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between p-4 bg-white border-b border-burgundy/5 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-2">
          <CircleDot className="text-burgundy w-6 h-6" />
          <h1 className="font-serif text-lg font-bold tracking-tight text-burgundy">Grand Cru</h1>
        </div>
        <button onClick={() => setSidebarOpen(true)}>
          <Menu className="text-burgundy" />
        </button>
      </header>

      {/* Sidebar Overlay for Mobile */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-charcoal/40 backdrop-blur-sm z-[60] md:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar - Fixed on desktop, slide-over on mobile */}
      <aside className={`
        fixed inset-y-0 left-0 z-[70] w-64 flex flex-col bg-white border-r border-burgundy/10 transition-transform duration-300 shadow-premium
        ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="p-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-burgundy rounded-lg shadow-burgundy-glow">
              <WineIcon className="w-6 h-6 text-alabaster" />
            </div>
            <div className="flex flex-col">
              <span className="font-serif text-xl font-bold text-burgundy leading-none">CRU</span>
              <span className="text-[10px] tracking-[0.2em] text-stone-gray font-medium uppercase">Vault & Portfolio</span>
            </div>
          </div>
          <button className="md:hidden" onClick={() => setSidebarOpen(false)}>
            <X className="w-6 h-6 text-stone-gray" />
          </button>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-2 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={`
                  flex items-center justify-between px-4 py-3 rounded-xl transition-all duration-300 group
                  ${isActive 
                    ? 'bg-burgundy-mist text-burgundy font-bold' 
                    : 'text-stone-gray hover:bg-alabaster hover:text-charcoal'}
                `}
              >
                <div className="flex items-center gap-3">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-burgundy' : 'group-hover:text-burgundy transition-colors'}`} />
                  <span className="font-medium">{item.label}</span>
                </div>
                {isActive && <ChevronRight className="w-4 h-4 text-burgundy" />}
              </Link>
            );
          })}
        </nav>

        <div className="p-6 border-t border-alabaster space-y-4">
          <div className={`p-4 rounded-xl border flex flex-col gap-2 ${isGuest ? 'bg-gold/5 border-gold/10' : 'bg-alabaster border-burgundy/5'}`}>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full animate-pulse ${isGuest ? 'bg-gold' : 'bg-sage'}`} />
              <span className="text-[9px] font-black text-stone-gray uppercase tracking-widest">
                {isGuest ? 'Demo-Modus' : 'Verbunden als'}
              </span>
            </div>
            <div className="flex items-center gap-2">
              {isGuest && <Sparkles className="w-3 h-3 text-gold" />}
              <span className="text-xs text-charcoal font-bold truncate">
                {isGuest ? 'Gast-Sammler' : user?.email}
              </span>
            </div>
            <button 
              onClick={handleLogout}
              className="mt-2 flex items-center gap-2 text-[10px] font-black text-burgundy/60 hover:text-burgundy transition-colors uppercase tracking-widest"
            >
              <LogOut className="w-3 h-3" />
              {isGuest ? 'Beenden' : 'Abmelden'}
            </button>
          </div>

          <div className="p-4 bg-alabaster-dark rounded-xl border border-burgundy/5 flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-burgundy" />
            <div className="flex flex-col">
              <span className="text-[10px] text-stone-gray uppercase tracking-widest font-bold">Cloud Sync</span>
              <span className="text-xs text-charcoal font-medium">Safe & Secure</span>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 md:pl-64 transition-all duration-300">
        <main className="min-h-screen p-4 md:p-10 pb-24 md:pb-10 relative">
          <div className="max-w-6xl mx-auto">
            {children}
          </div>
          
          {/* Decorative Gradients */}
          <div className="fixed top-0 right-0 w-[500px] h-[500px] bg-gold/5 blur-[120px] pointer-events-none z-0" />
          <div className="fixed bottom-0 left-0 w-[300px] h-[300px] bg-burgundy/5 blur-[100px] pointer-events-none z-0" />
        </main>
      </div>
    </div>
  );
};
