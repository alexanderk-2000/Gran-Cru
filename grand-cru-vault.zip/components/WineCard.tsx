
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Wine, WineStatus } from '../types.ts';
import { getWineStatus, formatCurrency } from '../utils.ts';
import { Wine as WineIcon, TrendingUp, Calendar, ShoppingCart, Plus, Minus, ChevronRight } from 'lucide-react';
import { storageService } from '../services/storage.ts';

interface WineCardProps {
  wine: Wine;
  onDrink?: (wine: Wine) => void;
  onEdit?: (wine: Wine) => void;
  onUpdate?: () => void;
}

export const WineCard: React.FC<WineCardProps> = ({ wine, onDrink, onEdit, onUpdate }) => {
  const status = getWineStatus(wine);
  const isReady = status === WineStatus.READY;
  const isEmpty = wine.quantity === 0;

  const handleAdjust = (e: React.MouseEvent, delta: number) => {
    e.preventDefault();
    e.stopPropagation();
    storageService.adjustStock(wine.id, delta, 'dashboard');
    if (onUpdate) onUpdate();
  };

  const getStatusBadge = () => {
    switch (status) {
      case WineStatus.READY:
        return <span className="px-2 py-0.5 rounded-full text-[10px] bg-sage-light text-sage border border-sage font-bold uppercase tracking-tighter">Trinkreif</span>;
      case WineStatus.HOLD:
        return <span className="px-2 py-0.5 rounded-full text-[10px] bg-alabaster text-gold border border-gold font-bold uppercase tracking-tighter">Halten</span>;
      case WineStatus.PAST_PEAK:
        return <span className="px-2 py-0.5 rounded-full text-[10px] bg-red-50 text-red-700 border border-red-200 font-bold uppercase tracking-tighter">Über Peak</span>;
    }
  };

  return (
    <div className={`
      relative group overflow-hidden rounded-2xl border transition-all duration-500 bg-white shadow-premium
      ${isReady ? 'border-gold/30 ring-1 ring-gold/10' : 'border-burgundy/5'}
      ${isEmpty ? 'opacity-60 grayscale' : 'hover:scale-[1.01] hover:shadow-xl'}
    `}>
      <div className="p-6">
        <div className="flex justify-between items-start mb-4">
          <Link to={`/wine/${wine.id}`} className="flex-1 flex flex-col group/title">
            <span className="text-xs font-medium text-stone-gray uppercase tracking-widest mb-1">{wine.region}</span>
            <h3 className="font-serif text-xl font-bold text-charcoal group-hover/title:text-burgundy transition-colors flex items-center gap-1">
              {wine.name}
              <ChevronRight className="w-4 h-4 opacity-0 group-hover/title:opacity-100 transition-all translate-x-[-4px] group-hover/title:translate-x-0" />
            </h3>
          </Link>
          <div className="flex flex-col items-end gap-2 shrink-0">
            <span className="font-serif text-lg font-bold text-burgundy">{wine.vintage}</span>
            {getStatusBadge()}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 py-4 border-y border-alabaster mb-4">
          <div className="flex flex-col gap-1">
            <div className="flex items-center gap-2 text-stone-gray">
              <span className="text-[10px] font-black uppercase tracking-widest">Stock</span>
            </div>
            <div className="flex items-center gap-3">
              <button 
                onClick={(e) => handleAdjust(e, -1)}
                disabled={wine.quantity === 0}
                className="p-1 rounded bg-alabaster border border-burgundy/5 hover:border-burgundy/20 text-burgundy disabled:opacity-30 transition-all"
              >
                <Minus className="w-3 h-3" />
              </button>
              <span className="text-sm font-bold text-charcoal">{wine.quantity} <span className="text-[10px] text-stone-gray font-normal">Fl.</span></span>
              <button 
                onClick={(e) => handleAdjust(e, 1)}
                className="p-1 rounded bg-alabaster border border-burgundy/5 hover:border-burgundy/20 text-burgundy transition-all"
              >
                <Plus className="w-3 h-3" />
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-1 items-end">
            <span className="text-[10px] font-black uppercase tracking-widest text-stone-gray">Einstand Ø</span>
            <span className="text-sm font-bold text-charcoal">{formatCurrency(wine.purchase_price)}</span>
          </div>
          <div className="flex items-center gap-2 col-span-2 text-stone-gray">
            <Calendar className="w-4 h-4 text-gold" />
            <span className="text-sm">Fenster: <span className="font-medium text-charcoal">{wine.drink_start} – {wine.drink_end}</span></span>
          </div>
        </div>

        <div className="flex gap-2">
          <Link
            to={`/wine/${wine.id}?action=buy`}
            className="flex-1 py-2 bg-white border border-burgundy/10 hover:border-burgundy/30 text-burgundy text-[10px] font-black rounded-lg transition-all uppercase tracking-widest flex items-center justify-center gap-2"
          >
            <ShoppingCart className="w-3 h-3" />
            Kaufen
          </Link>
          <Link
            to={`/wine/${wine.id}`}
            className="px-4 py-2 bg-burgundy hover:bg-burgundy-light text-white text-[10px] font-black rounded-lg transition-colors flex items-center justify-center uppercase tracking-widest"
          >
            Details
          </Link>
        </div>
      </div>
    </div>
  );
};
