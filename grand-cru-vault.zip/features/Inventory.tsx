
import React, { useState, useMemo } from 'react';
import { Wine, Category, WineStatus } from '../types.ts';
import { WineCard } from '../components/WineCard.tsx';
import { Search, Filter, Plus, X, Loader2, Wand2, Globe, ExternalLink } from 'lucide-react';
import { getWineStatus, handleAiOperationError } from '../utils.ts';
import { GoogleGenAI } from "@google/genai";
import { storageService } from '../services/storage.ts';
import { Badge } from '../components/Badge.tsx';
import { getApiKey } from '../utils/env.ts';

interface InventoryProps {
  wines: Wine[];
  wishlistOnly?: boolean;
  onWineUpdate: () => void;
  onAddBottle: (wine: Partial<Wine>) => void;
  onDrink: (wine: Wine) => void;
}

export const Inventory: React.FC<InventoryProps> = ({ 
  wines, 
  wishlistOnly = false, 
  onDrink,
  onWineUpdate
}) => {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<Category | 'All'>('All');
  const [statusFilter, setStatusFilter] = useState<WineStatus | 'All'>('All');
  
  // AI States
  const [isAiModalOpen, setIsAiModalOpen] = useState(false);
  const [aiInput, setAiInput] = useState('');
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiPreview, setAiPreview] = useState<Partial<Wine> | null>(null);
  const [sources, setSources] = useState<{title: string, uri: string}[]>([]);

  const filteredWines = useMemo(() => {
    return wines.filter(wine => {
      if (wine.wishlist !== wishlistOnly) return false;
      const matchesSearch = wine.name.toLowerCase().includes(search.toLowerCase()) || 
                          wine.region.toLowerCase().includes(search.toLowerCase()) ||
                          wine.producer?.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = categoryFilter === 'All' || wine.category === categoryFilter;
      const matchesStatus = statusFilter === 'All' || getWineStatus(wine) === statusFilter;
      return matchesSearch && matchesCategory && matchesStatus;
    });
  }, [wines, search, categoryFilter, statusFilter, wishlistOnly]);

  const handleAiSearch = async () => {
    if (!aiInput.trim()) return;
    setIsAiLoading(true);
    setAiPreview(null);
    setSources([]);

    try {
      const apiKey = getApiKey();
      if (!apiKey) throw new Error("API Key missing");
      
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Recherchiere den Wein: "${aiInput}" 
ausschließlich in den folgenden sieben Quellen:
1) gute-weine.de 2) wine-in-black.de 3) millesima.de 4) wine.com 5) winespectator.com 6) robertparker.com 7) wine-searcher.com
Antworte streng im JSON-Format.`,
        config: {
          systemInstruction: `Du bist ein oenologischer Experte. Nutze NUR die genannten Quellen. Antworte exklusiv als JSON.
Schema:
{
  "canonical": {
    "name": string, "vintage": number, "producer": string, "region": string, "market_price": number, "drink_start": number, "drink_end": number
  },
  "confidence": string,
  "missing_fields": string[]
}`,
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json"
        }
      });

      const data = JSON.parse(response.text);
      
      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (groundingChunks) {
        const extractedSources = groundingChunks
          .filter((chunk: any) => chunk.web)
          .map((chunk: any) => ({
            title: chunk.web.title || 'Quelle',
            uri: chunk.web.uri
          }));
        setSources(extractedSources);
      }

      setAiPreview({
        ...data.canonical,
        confidence: data.confidence || 'medium',
        missing_fields: data.missing_fields || [],
        format: '0.75L',
        quantity: 1,
        purchase_price: data.canonical?.market_price || 0,
        wishlist: wishlistOnly,
      });
    } catch (error) {
      handleAiOperationError(error);
    } finally {
      setIsAiLoading(false);
    }
  };

  const manualAdd = async () => {
    await storageService.saveWine({
      name: 'Neuer Wein',
      vintage: new Date().getFullYear(),
      region: 'Unbekannt',
      category: 'Daily Drinker',
      quantity: 1,
      purchase_price: 0,
      format: '0.75L',
      drink_start: new Date().getFullYear(),
      drink_end: new Date().getFullYear() + 10,
      wishlist: wishlistOnly
    });
    onWineUpdate();
    setIsAiModalOpen(false);
  };

  const confirmAiAddition = async () => {
    if (aiPreview) {
      await storageService.saveWine(aiPreview);
      onWineUpdate();
      setIsAiModalOpen(false);
      setAiPreview(null);
      setAiInput('');
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex flex-col gap-2">
          <h2 className="font-serif text-4xl font-bold text-charcoal">
            {wishlistOnly ? 'Wunschliste' : 'Hauptkeller'}
          </h2>
          <p className="text-stone-gray font-medium tracking-wide">
            {wishlistOnly ? 'Geplante Ergänzungen.' : 'Verwaltung Ihrer flüssigen Assets.'}
          </p>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setIsAiModalOpen(true)} className="flex items-center gap-2 px-6 py-3.5 bg-burgundy hover:bg-burgundy-light text-white font-black rounded-2xl transition-all shadow-premium uppercase tracking-wider text-[10px]">
            <Plus className="w-4 h-4" /> NEU ANLEGEN
          </button>
        </div>
      </header>

      <div className="flex flex-col md:flex-row gap-4 p-4 bg-white border-2 border-burgundy/5 rounded-[2rem] shadow-premium">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-gray" />
          <input 
            type="text" placeholder="Kollektion durchsuchen..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-12 pr-4 py-3.5 bg-alabaster border-2 border-transparent rounded-[1.25rem] text-sm focus:outline-none focus:border-burgundy/20 transition-all font-medium"
          />
        </div>
        <div className="flex gap-2">
          <FilterSelect value={categoryFilter} onChange={setCategoryFilter} options={[{label: 'Alle Kategorien', value: 'All'}, {label: 'Genuss', value: 'Genuss'}, {label: 'Investment', value: 'Investment'}, {label: 'Rarität', value: 'Rarität'}]} />
          <FilterSelect value={statusFilter} onChange={setStatusFilter} options={[{label: 'Jeder Status', value: 'All'}, {label: 'Trinkreif', value: WineStatus.READY}, {label: 'Lagernd', value: WineStatus.HOLD}, {label: 'Vergangen', value: WineStatus.PAST_PEAK}]} />
        </div>
      </div>

      {isAiModalOpen && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-charcoal/40 backdrop-blur-md animate-in fade-in">
          <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl border border-burgundy/5 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-8 border-b border-alabaster flex justify-between items-center bg-alabaster/30">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-burgundy text-white rounded-2xl shadow-burgundy-glow"><Wand2 className="w-6 h-6" /></div>
                <h3 className="font-serif text-2xl font-bold text-charcoal">Smart Assistant</h3>
              </div>
              <button onClick={() => setIsAiModalOpen(false)} className="p-2"><X /></button>
            </div>
            <div className="p-10 space-y-10 overflow-y-auto">
              <div className="space-y-4">
                <div className="flex gap-4">
                  <input type="text" placeholder="Weinname & Jahrgang..." value={aiInput} onChange={(e) => setAiInput(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleAiSearch()} className="flex-1 px-6 py-4 bg-alabaster border-2 border-burgundy/5 rounded-2xl focus:outline-none focus:border-burgundy/30 font-serif" />
                  <button onClick={handleAiSearch} disabled={isAiLoading || !aiInput.trim()} className="px-8 bg-burgundy text-white rounded-2xl font-black hover:bg-burgundy-light transition-all disabled:opacity-50 uppercase tracking-widest text-[10px]">
                    {isAiLoading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'RECHERCHIEREN'}
                  </button>
                </div>
                <button onClick={manualAdd} className="text-[10px] font-black text-stone-gray hover:text-burgundy uppercase tracking-widest block mx-auto">Manuell anlegen</button>
              </div>
              {aiPreview && (
                <div className="animate-in slide-in-from-bottom-8 duration-700 space-y-8">
                  <div className="p-8 bg-white rounded-[2.5rem] border-2 border-burgundy/10 shadow-premium">
                    <div className="flex justify-between items-start mb-4">
                      <Badge variant="gold">Confidence: {aiPreview.confidence}</Badge>
                    </div>
                    <h4 className="font-serif text-3xl font-bold text-charcoal">{aiPreview.name}</h4>
                    <p className="text-gold font-serif text-2xl">{aiPreview.vintage}</p>
                    
                    {sources.length > 0 && (
                      <div className="mt-4 pt-4 border-t border-alabaster">
                        <p className="text-[9px] font-black uppercase tracking-widest text-stone-gray mb-2 flex items-center gap-1">
                          <Globe className="w-3 h-3" /> Recherche-Quellen
                        </p>
                        <div className="flex wrap gap-2">
                          {sources.map((src, i) => (
                            <a key={i} href={src.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-[10px] text-burgundy hover:underline font-bold">
                              {src.title} <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                  <button onClick={confirmAiAddition} className="w-full py-5 bg-burgundy text-white font-black rounded-2xl shadow-xl uppercase tracking-widest text-xs">Kellerübernahme</button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {filteredWines.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pb-20">
          {filteredWines.map(wine => (
            <WineCard key={wine.id} wine={wine} onDrink={onDrink} onUpdate={onWineUpdate} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-32 bg-white rounded-[3rem] border-2 border-dashed border-burgundy/10">
          <Search className="w-16 h-16 text-burgundy/10 mb-6" />
          <p className="text-stone-gray max-w-sm mx-auto">Starten Sie Ihre Kollektion.</p>
        </div>
      )}
    </div>
  );
};

const FilterSelect = ({ value, onChange, options }: any) => (
  <select value={value} onChange={(e) => onChange(e.target.value as any)} className="px-6 py-3.5 bg-alabaster border-2 border-transparent rounded-[1.25rem] text-xs font-black text-charcoal focus:outline-none appearance-none hover:border-burgundy/10">
    {options.map((opt: any) => (<option key={opt.value} value={opt.value}>{opt.label}</option>))}
  </select>
);
