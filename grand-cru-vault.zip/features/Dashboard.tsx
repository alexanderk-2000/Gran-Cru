
import React, { useMemo } from 'react';
import { Wine, PortfolioStats } from '../types.ts';
import { calculatePortfolioStats, formatCurrency } from '../utils.ts';
import { 
  TrendingUp, 
  Clock, 
  CheckCircle2, 
  Layers,
  ArrowUpRight,
  ShieldCheck,
  Zap
} from 'lucide-react';

export const Dashboard: React.FC<{ wines: Wine[] }> = ({ wines }) => {
  const stats = useMemo(() => calculatePortfolioStats(wines), [wines]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col gap-2">
        <h2 className="font-serif text-4xl font-bold text-charcoal">Portfolio Übersicht</h2>
        <p className="text-stone-gray font-medium tracking-wide">Analytik und Bestandsverwaltung Ihrer Grand Cru Sammlung.</p>
      </header>

      {/* Hero Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard 
          label="Marktwert" 
          value={formatCurrency(stats.totalValue)} 
          icon={TrendingUp} 
          trend="Live Portfolio"
          color="burgundy"
        />
        <StatCard 
          label="Gesamtbestand" 
          value={`${stats.totalBottles} Fl.`} 
          icon={Layers}
          color="charcoal"
        />
        <StatCard 
          label="Trinkbereit" 
          value={stats.readyCount.toString()} 
          icon={CheckCircle2} 
          color="sage"
        />
        <StatCard 
          label="Durchschnittsalter" 
          value={`${stats.averageAge} Jahre`} 
          icon={Clock} 
          color="gold"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cellar Maturity Breakdown */}
        <div className="lg:col-span-2 bg-white border border-burgundy/5 p-8 rounded-3xl relative overflow-hidden shadow-premium group">
          <div className="relative z-10">
            <div className="flex items-end justify-between mb-8">
              <div>
                <h3 className="font-serif text-2xl font-bold text-burgundy mb-1">Keller Reife-Profil</h3>
                <p className="text-sm text-stone-gray">Verteilung des optimalen Genusses</p>
              </div>
              <div className="text-right">
                <span className="block text-4xl font-bold font-serif text-charcoal">{stats.holdCount}</span>
                <span className="text-xs uppercase tracking-widest text-gold font-bold">Flaschen in Reifung</span>
              </div>
            </div>

            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                 <div className="bg-alabaster p-4 rounded-xl border border-burgundy/5">
                   <p className="text-[10px] font-black text-stone-gray uppercase tracking-widest mb-1">Bereit</p>
                   <p className="text-xl font-serif font-bold text-sage">{stats.readyCount}</p>
                 </div>
                 <div className="bg-alabaster p-4 rounded-xl border border-burgundy/5">
                   <p className="text-[10px] font-black text-stone-gray uppercase tracking-widest mb-1">Lagernd</p>
                   <p className="text-xl font-serif font-bold text-gold">{stats.holdCount}</p>
                 </div>
                 <div className="bg-alabaster p-4 rounded-xl border border-burgundy/5">
                   <p className="text-[10px] font-black text-stone-gray uppercase tracking-widest mb-1">Investment</p>
                   <p className="text-xl font-serif font-bold text-burgundy">{wines.filter(w => w.category === 'Investment').length}</p>
                 </div>
              </div>
              
              <div className="h-4 bg-alabaster rounded-full overflow-hidden border border-burgundy/5">
                <div 
                  className="h-full bg-gradient-to-r from-sage to-gold transition-all duration-1000 ease-out"
                  style={{ width: `${(stats.readyCount / (stats.totalBottles || 1)) * 100}%` }}
                />
              </div>
              <p className="text-xs text-stone-gray italic text-center">Visualisierung der sofortigen Trinkbereitschaft vs. Langzeitlagerung.</p>
            </div>
          </div>
        </div>

        {/* Financial Overview */}
        <div className="bg-white border border-burgundy/5 p-8 rounded-3xl shadow-premium">
          <h3 className="font-serif text-xl font-bold text-charcoal mb-6 flex items-center gap-2">
             Asset Verteilung <ShieldCheck className="w-4 h-4 text-burgundy" />
          </h3>
          <div className="space-y-6">
             <div className="flex justify-between items-center">
               <span className="text-sm text-stone-gray font-medium">Investment Anteil</span>
               <span className="text-sm font-bold text-burgundy">{formatCurrency(stats.investmentValue)}</span>
             </div>
             <div className="h-1.5 bg-alabaster rounded-full overflow-hidden">
                <div className="h-full bg-burgundy" style={{ width: `${(stats.investmentValue / (stats.totalValue || 1)) * 100}%` }} />
             </div>
             
             <div className="flex justify-between items-center">
               <span className="text-sm text-stone-gray font-medium">Genuss Anteil</span>
               <span className="text-sm font-bold text-charcoal">{formatCurrency(stats.totalValue - stats.investmentValue)}</span>
             </div>
             <div className="h-1.5 bg-alabaster rounded-full overflow-hidden">
                <div className="h-full bg-gold" style={{ width: `${((stats.totalValue - stats.investmentValue) / (stats.totalValue || 1)) * 100}%` }} />
             </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-alabaster">
            <div className="flex items-start gap-3">
              <Zap className="w-4 h-4 text-gold shrink-0 mt-0.5" />
              <p className="text-xs text-stone-gray">Ihr Portfolio ist zu {stats.totalValue > 0 ? Math.round((stats.investmentValue / stats.totalValue) * 100) : 0}% auf Wertsteigerung fokussiert.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard = ({ label, value, icon: Icon, trend, color }: any) => {
  const iconColors = {
    burgundy: 'text-burgundy bg-burgundy/10',
    charcoal: 'text-charcoal bg-alabaster',
    sage: 'text-sage bg-sage-light',
    gold: 'text-gold bg-alabaster'
  }[color as 'burgundy' | 'charcoal' | 'sage' | 'gold'];

  return (
    <div className={`p-6 rounded-2xl bg-white border border-burgundy/5 shadow-premium group transition-all duration-300 hover:scale-[1.02]`}>
      <div className="flex items-start justify-between mb-4">
        <div className={`p-2.5 rounded-lg ${iconColors}`}>
          <Icon className="w-5 h-5" />
        </div>
        {trend && <span className="text-[10px] font-bold text-sage bg-sage-light px-2 py-0.5 rounded-full">{trend}</span>}
      </div>
      <div>
        <p className="text-xs font-bold text-stone-gray uppercase tracking-widest mb-1">{label}</p>
        <p className="text-2xl font-serif font-bold text-charcoal group-hover:text-burgundy transition-colors">{value}</p>
      </div>
    </div>
  );
};
