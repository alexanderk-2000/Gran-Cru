
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { Wine, Tasting } from '../types.ts';
import { storageService } from '../services/storage.ts';
import { formatCurrency, getWineStatus, handleAiOperationError, calculateDrinkability } from '../utils.ts';
import { GoogleGenAI } from "@google/genai";
import { 
  ArrowLeft, ShoppingBag, Plus, Minus, X, Droplets, Loader2, 
  Edit3, Trash2, MapPin, Wind, Activity, Utensils, Award, Grape, 
  Leaf, FlaskConical, Container, Star, Info, GlassWater, Beef, Fish, ChefHat, Pizza, Check, Wand2, Globe, Scale, History, ShieldCheck, ExternalLink, Tag
} from 'lucide-react';
import { Badge } from '../components/Badge.tsx';
import { getApiKey } from '../utils/env.ts';

export const WineDetail: React.FC<{ onDrink: (wine: Wine) => void }> = ({ onDrink }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const [wine, setWine] = useState<Wine | null>(null);
  const [tastings, setTastings] = useState<Tasting[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  const [isAiLoading, setIsAiLoading] = useState(false);
  
  // Modals
  const [isPurchaseModalOpen, setIsPurchaseModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);

  // Transaction State
  const [purchaseQty, setPurchaseQty] = useState(1);
  const [purchasePrice, setPurchasePrice] = useState(0);

  // Edit State
  const [editForm, setEditForm] = useState<Partial<Wine>>({});

  useEffect(() => {
    const loadData = async () => {
      if (id) {
        const w = await storageService.getWineById(id);
        if (w) {
          setWine(w);
          setEditForm(w);
          setPurchasePrice(w.purchase_price || 0);
          
          // Load History
          const history = await storageService.getTastings(id);
          setTastings(history);
        } else navigate('/inventory');
      }
    };
    loadData();
  }, [id, navigate]);

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    if (params.get('action') === 'buy') setIsPurchaseModalOpen(true);
  }, [location.search]);

  // --- ACTIONS ---

  const handleAdjustStock = async (delta: number) => {
    if (!wine || isSaving) return;
    setIsSaving(true);
    try {
      const updated = await storageService.adjustStock(wine.id, delta, 'detail');
      if (updated) setWine(updated as Wine);
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleRegisterPurchase = async () => {
    if (!wine || isSaving) return;
    setIsSaving(true);
    try {
      const updated = await storageService.recordPurchase({
        wine_id: wine.id,
        quantity: purchaseQty,
        price_per_bottle: purchasePrice,
        date: new Date().toISOString()
      });
      if (updated) {
        setWine(updated);
        setIsPurchaseModalOpen(false);
        setPurchaseQty(1);
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async () => {
    if (!wine) return;
    const reason = window.prompt("Möchten Sie diesen Wein wirklich in den Papierkorb verschieben? Geben Sie optional einen Grund an:", "Manuelle Bereinigung");
    if (reason === null) return; 
    setIsSaving(true);
    try {
      await storageService.softDeleteWine(wine.id, reason);
      navigate('/inventory');
    } catch (err: any) {
      alert(err.message);
      setIsSaving(false);
    }
  };

  const handleAiLookup = async () => {
    if (!wine) return;
    setIsAiLoading(true);
    try {
      const apiKey = getApiKey();
      if (!apiKey) throw new Error("API Key missing");

      const ai = new GoogleGenAI({ apiKey });
      const prompt = `Recherchiere den Wein: "${wine.vintage} ${wine.producer || ''} ${wine.name}"

Nutze AUSSCHLIESSLICH die folgenden sieben Quellen:
1) https://www.gute-weine.de
2) https://www.wine-in-black.de
3) https://www.millesima.de
4) https://www.wine.com
5) https://www.winespectator.com
6) https://www.robertparker.com
7) https://www.wine-searcher.com/

IGNORIERE alle anderen Quellen, Websites, Datenbanken oder Annahmen.

----------------------------------------------------------
AGGREGATIONSLOGIK:
----------------------------------------------------------
• Rebsorten → häufigster Wert
• Alkoholgehalt → häufigster Wert
• Region/Land/Appellation → häufigste Kombination
• Trinkfenster → start=min, end=max
• Aromatik → Top 5-6 Aromen
• Struktur (1-5)
• Kritikerpunkte → Scores extrahieren

{
  "name": "...",
  "producer": "...",
  "vintage": ...,
  "region": "...",
  "country": "...",
  "appellation": "...",
  "grapes": ["..."],
  "alcohol_percent": ...,
  "drink_start": ...,
  "drink_end": ...,
  "peak_year": ...,
  "aromas": [{ "tag": "...", "intensity": 1-5 }],
  "structure": { "acidity": 1-5, "tannin": 1-5, "body": 1-5, "sweetness": 1-5, "oak": 1-5 },
  "pairings": [{ "item": "...", "category": "...", "note": "..." }],
  "vinification": { "closure_type": "...", "aging_process": "...", "farming": "...", "fermentation": "...", "maturation_profile": "..." },
  "scores": [{ "source": "...", "value": ... }],
  "confidence": "high | medium | low",
  "missing_fields": ["..."]
}`;

      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: prompt,
        config: {
          systemInstruction: "Du bist ein oenologischer Experte. Nutze AUSSCHLIESSLICH die 7 genannten Quellen. Antworte exklusiv als JSON.",
          tools: [{ googleSearch: {} }],
          responseMimeType: "application/json"
        }
      });
      
      const data = JSON.parse(response.text);
      
      const mappedData: Partial<Wine> = {
        name: data.name || wine.name,
        producer: data.producer || wine.producer,
        vintage: data.vintage || wine.vintage,
        region: data.region || wine.region,
        country: data.country || wine.country,
        appellation: data.appellation || wine.appellation,
        grapes: data.grapes ? data.grapes.map((g: string) => ({ name: g })) : wine.grapes,
        alcohol_percent: data.alcohol_percent || wine.alcohol_percent,
        drink_start: data.drink_start || wine.drink_start,
        drink_end: data.drink_end || wine.drink_end,
        peak_year: data.peak_year || wine.peak_year,
        aromas: data.aromas || wine.aromas,
        structure: data.structure || wine.structure,
        pairings: data.pairings || wine.pairings,
        scores: data.scores ? data.scores.map((s: any) => ({ critic: s.source, score: s.value })) : wine.scores,
        closure_type: data.vinification?.closure_type || wine.closure_type,
        aging_process: data.vinification?.aging_process || wine.aging_process,
        farming: data.vinification?.farming || wine.farming,
        fermentation: data.vinification?.fermentation || wine.fermentation,
        maturation_profile: data.vinification?.maturation_profile || wine.maturation_profile,
        confidence: data.confidence || 'medium',
        missing_fields: data.missing_fields || [],
        updated_at: new Date().toISOString()
      };

      const updated = await storageService.saveWine({ ...wine, ...mappedData });
      setWine(updated);
      setEditForm(updated);
    } catch (error) {
      handleAiOperationError(error);
    } finally {
      setIsAiLoading(false);
    }
  };

  if (!wine) return null;

  const drinkability = calculateDrinkability(wine);
  const status = getWineStatus(wine);

  return (
    <div className="min-h-screen bg-alabaster/40 animate-in fade-in duration-700 pb-40">
      <div className="bg-white border-b border-burgundy/5 pt-16 pb-12 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-start gap-8">
            <div className="space-y-4 flex-1">
              <button onClick={() => navigate(-1)} className="group flex items-center gap-2 text-stone-gray hover:text-burgundy uppercase text-[10px] font-black tracking-widest transition-all mb-6">
                <ArrowLeft className="w-3 h-3 group-hover:-translate-x-1" /> Zurück zum Keller
              </button>
              <div className="flex flex-wrap items-center gap-2 mb-2">
                <Badge variant="bordeaux">{wine.category}</Badge>
                <Badge variant="gold">{wine.wine_type || 'Wein'}</Badge>
                {wine.is_favorite && <Badge variant="gold"><Star className="w-3 h-3 fill-current" /> Favorit</Badge>}
              </div>
              <div className="space-y-1">
                <h1 className="font-serif text-5xl md:text-7xl font-bold text-charcoal leading-tight">
                  <span className="text-burgundy opacity-90">{wine.vintage || 'NV'}</span> {wine.name}
                </h1>
                <p className="text-xl md:text-2xl text-stone-gray font-serif italic tracking-wide">
                  {wine.producer} {wine.appellation ? `— ${wine.appellation}` : ''}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-2 pt-4 text-stone-gray text-xs font-medium uppercase tracking-[0.15em]">
                <span className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> {wine.region}</span>
                <span className="w-1.5 h-1.5 bg-stone-gray/20 rounded-full" />
                <span className="flex items-center gap-1.5"><Globe className="w-3.5 h-3.5" /> {wine.country || 'Herkunft unbekannt'}</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-3 md:pt-12">
               <button 
                onClick={() => setIsEditModalOpen(true)} 
                className="p-3 bg-white border border-burgundy/10 rounded-2xl text-stone-gray hover:text-burgundy hover:border-burgundy/30 transition-all shadow-sm"
              >
                <Edit3 className="w-5 h-5" />
              </button>
              <button 
                onClick={handleAiLookup} 
                disabled={isAiLoading}
                className="flex items-center gap-2 px-6 py-3 bg-white border border-burgundy/10 text-burgundy rounded-2xl text-[10px] font-black uppercase tracking-widest hover:border-burgundy/30 hover:bg-alabaster transition-all shadow-sm disabled:opacity-50"
              >
                {isAiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4 text-gold" />}
                {isAiLoading ? 'Analyse...' : 'KI-Upgrade'}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 mt-12 grid grid-cols-1 lg:grid-cols-12 gap-12 relative">
        <div className="lg:col-span-8 space-y-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <MetricCard label="Kategorie" value={wine.category} icon={Tag} />
             <MetricCard label="Typ" value={wine.wine_type || 'Stillwein'} icon={Droplets} />
             <MetricCard label="Alkohol" value={wine.alcohol_percent ? `${wine.alcohol_percent}%` : 'N/A'} icon={Scale} />
             <MetricCard label="Format" value={wine.format} icon={Container} />
          </div>

          <section className="bg-white rounded-[2.5rem] border border-burgundy/5 shadow-premium overflow-hidden">
             <div className="p-8 md:p-10">
               <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8 mb-10">
                 <div>
                   <h3 className="font-serif text-2xl font-bold text-charcoal mb-2">Trinkreife & Horizont</h3>
                   <p className="text-sm text-stone-gray font-medium">Optimaler Zeitraum für maximale Komplexität.</p>
                 </div>
                 <div className="flex items-center gap-6">
                   <div className="text-right">
                     <p className="text-[10px] font-black uppercase tracking-widest text-stone-gray mb-1">Index Score</p>
                     <p className="text-4xl font-serif font-bold text-burgundy">{Math.round(drinkability.score)}<span className="text-lg opacity-30">/100</span></p>
                   </div>
                   <div className={`px-5 py-2 rounded-full border text-[10px] font-black uppercase tracking-widest shadow-sm
                     ${status === 'READY' ? 'bg-sage-light text-sage border-sage/20' : ''}
                     ${status === 'HOLD' ? 'bg-gold/5 text-gold border-gold/20' : ''}
                     ${status === 'PAST_PEAK' ? 'bg-red-50 text-red-600 border-red-100' : ''}
                   `}>
                     {drinkability.status}
                   </div>
                 </div>
               </div>
               <div className="space-y-6">
                 <div className="flex justify-between items-end mb-2">
                    <div className="text-center w-24">
                      <p className="text-[10px] font-black text-stone-gray uppercase mb-1">Beginn</p>
                      <p className="text-xl font-serif font-bold text-charcoal">{wine.drink_start}</p>
                    </div>
                    <div className="flex-1 px-4 pb-2">
                       <div className="relative h-3 bg-alabaster rounded-full overflow-hidden shadow-inner">
                          <div 
                            className="absolute h-full bg-gradient-to-r from-gold/40 via-burgundy to-gold/40 transition-all duration-1000" 
                            style={{ width: `${drinkability.wu * 100}%` }}
                          />
                       </div>
                    </div>
                    <div className="text-center w-24">
                      <p className="text-[10px] font-black text-stone-gray uppercase mb-1">Ende</p>
                      <p className="text-xl font-serif font-bold text-charcoal">{wine.drink_end}</p>
                    </div>
                 </div>
                 <p className="text-center text-xs text-stone-gray italic">
                   {status === 'READY' 
                    ? 'Der Wein befindet sich aktuell in seinem optimalen Genussfenster.' 
                    : status === 'HOLD' 
                    ? `Noch ca. ${wine.drink_start - new Date().getFullYear()} Jahre bis zur optimalen Reife.` 
                    : 'Dieser Wein hat seinen Peak vermutlich bereits überschritten.'}
                 </p>
               </div>
             </div>
          </section>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ContentCard title="Rebsorten" icon={Grape}>
               <div className="flex wrap gap-2 py-2">
                 {wine.grapes && wine.grapes.length > 0 ? wine.grapes.map((g, i) => (
                   <div key={i} className="px-4 py-2 bg-alabaster border border-burgundy/5 rounded-xl flex items-center gap-3">
                      <span className="text-sm font-bold text-charcoal">{g.name}</span>
                      {g.percentage && <span className="text-[9px] font-black px-1.5 py-0.5 bg-white rounded shadow-sm text-stone-gray">{g.percentage}%</span>}
                   </div>
                 )) : <EmptyText>Keine Rebsorten-Details.</EmptyText>}
               </div>
            </ContentCard>
            <ContentCard title="Herkunft & Lage" icon={MapPin}>
               <div className="space-y-4 py-2">
                 <div className="flex flex-col gap-1 p-4 bg-alabaster/40 rounded-2xl border border-burgundy/5 mb-4">
                   <div className="flex items-center gap-2 mb-2">
                     <ShieldCheck className={`w-4 h-4 ${wine.confidence === 'high' ? 'text-sage' : 'text-gold'}`} />
                     <span className="text-[9px] font-black uppercase tracking-widest text-stone-gray">Confidence: {wine.confidence}</span>
                   </div>
                 </div>
                 <DataRow label="Land" value={wine.country} />
                 <DataRow label="Region" value={wine.region} />
                 <DataRow label="Appellation" value={wine.appellation} />
                 <DataRow label="Einzellage" value={wine.vineyard} highlight />
               </div>
            </ContentCard>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <ContentCard title="Aromatik" icon={Wind}>
               <div className="flex wrap gap-2 py-2">
                 {wine.aromas && wine.aromas.length > 0 ? wine.aromas.map((a, i) => (
                   <span key={i} className="px-4 py-2 rounded-xl text-xs font-bold border border-burgundy/5 bg-alabaster">
                     {a.tag}
                   </span>
                 )) : <EmptyText>Keine Aromen verfügbar.</EmptyText>}
               </div>
            </ContentCard>
            <ContentCard title="Strukturprofil" icon={Activity}>
               <div className="space-y-5 py-2">
                 <StructureRow label="Säure" value={wine.structure?.acidity} />
                 <StructureRow label="Tannin" value={wine.structure?.tannin} />
                 <StructureRow label="Körper" value={wine.structure?.body} />
                 <StructureRow label="Süße" value={wine.structure?.sweetness} />
                 <StructureRow label="Holz" value={wine.structure?.oak} />
               </div>
            </ContentCard>
          </div>

          <section className="bg-white rounded-[2.5rem] border border-burgundy/5 p-10 shadow-premium">
             <div className="flex items-center gap-4 mb-10 pb-4 border-b border-alabaster">
               <div className="p-3 bg-burgundy/5 rounded-2xl text-burgundy"><FlaskConical className="w-6 h-6" /></div>
               <h3 className="font-serif text-2xl font-bold text-charcoal">Vinifikation & Technik</h3>
             </div>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                <TechItem icon={Container} label="Ausbau" value={wine.aging_process} />
                <TechItem icon={Leaf} label="Anbau" value={wine.farming} />
                <TechItem icon={Check} label="Verschluss" value={wine.closure_type} />
             </div>
          </section>

          <section className="space-y-6">
             <h3 className="font-serif text-2xl font-bold text-charcoal flex items-center gap-3">
               <Utensils className="w-6 h-6 text-burgundy" /> Food Pairing
             </h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {wine.pairings && wine.pairings.length > 0 ? wine.pairings.map((p, i) => (
                 <div key={i} className="bg-white p-6 rounded-3xl border border-burgundy/5 shadow-sm flex items-start gap-4">
                   <div className="p-3 bg-alabaster rounded-2xl text-gold shrink-0">
                     {p.category?.includes('Fleisch') ? <Beef className="w-5 h-5" /> : p.category?.includes('Fisch') ? <Fish className="w-5 h-5" /> : p.category?.includes('Vegetarisch') ? <Leaf className="w-5 h-5" /> : <ChefHat className="w-5 h-5" />}
                   </div>
                   <div>
                     <p className="font-bold text-charcoal mb-1">{p.item}</p>
                     {p.note && <p className="text-xs text-stone-gray italic">{p.note}</p>}
                   </div>
                 </div>
               )) : <EmptyText>Keine Pairing-Empfehlungen.</EmptyText>}
             </div>
          </section>

          <section className="pt-12 border-t border-burgundy/5 space-y-10">
            <h3 className="font-serif text-2xl font-bold text-charcoal flex items-center gap-3">
              <History className="w-6 h-6 text-burgundy" /> Sammler-Timeline
            </h3>
            <div className="relative pl-8 border-l border-alabaster space-y-12">
              {tastings.length > 0 ? tastings.map(t => (
                <div key={t.id} className="relative">
                  <div className="bg-white p-8 rounded-3xl border border-burgundy/5 shadow-sm">
                    <div className="flex justify-between items-start mb-4">
                       <p className="text-[10px] font-black text-stone-gray uppercase">{new Date(t.date).toLocaleDateString('de-DE')}</p>
                       <div className="flex gap-0.5">
                         {[1,2,3,4,5].map(star => <Star key={star} className={`w-3 h-3 ${t.rating >= star ? 'text-gold fill-current' : 'text-stone-gray/10'}`} />)}
                       </div>
                    </div>
                    <p className="text-charcoal italic font-serif text-lg leading-relaxed">"{t.note}"</p>
                  </div>
                </div>
              )) : (
                <div className="text-center py-20 bg-white/50 border-2 border-dashed border-burgundy/5 rounded-[3rem]">
                   <p className="text-stone-gray text-sm">Noch keine Notizen.</p>
                </div>
              )}
            </div>
          </section>
        </div>

        <div className="lg:col-span-4 space-y-8">
           <div className="sticky top-10 space-y-8">
              <div className="bg-white rounded-[3rem] p-10 shadow-2xl border border-burgundy/5 text-center flex flex-col items-center">
                 <div className="flex items-center justify-center gap-8 mb-12">
                   <button onClick={() => handleAdjustStock(-1)} disabled={wine.quantity === 0 || isSaving} className="w-12 h-12 rounded-2xl border border-burgundy/10 flex items-center justify-center text-burgundy"><Minus className="w-5 h-5" /></button>
                   <div className="text-center min-w-[80px]">
                     <span className="text-8xl font-serif font-bold text-charcoal leading-none block">{wine.quantity}</span>
                     <span className="text-[10px] font-black text-stone-gray uppercase tracking-widest mt-2 block">Flaschen</span>
                   </div>
                   <button onClick={() => handleAdjustStock(1)} disabled={isSaving} className="w-12 h-12 rounded-2xl border border-burgundy/10 flex items-center justify-center text-burgundy"><Plus className="w-5 h-5" /></button>
                 </div>
                 <div className="w-full space-y-4">
                   <button onClick={() => onDrink(wine)} disabled={wine.quantity === 0 || isSaving} className="w-full py-5 bg-burgundy hover:bg-burgundy-light text-white font-black rounded-2xl shadow-xl uppercase tracking-widest text-[11px] flex items-center justify-center gap-3">
                     <GlassWater className="w-5 h-5" /> Flasche Genießen
                   </button>
                 </div>
              </div>
           </div>
        </div>
      </div>

      {isPurchaseModalOpen && (
        <Modal title="Nachkauf Erfassen" onClose={() => setIsPurchaseModalOpen(false)}>
           <div className="space-y-8 p-2">
             <div className="bg-alabaster p-8 rounded-[2rem] flex justify-between items-center border border-burgundy/5">
                <button onClick={() => setPurchaseQty(Math.max(1, purchaseQty - 1))} className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-burgundy"><Minus className="w-6 h-6" /></button>
                <div className="text-center">
                  <span className="font-serif text-6xl font-bold text-charcoal">{purchaseQty}</span>
                  <p className="text-[10px] font-black text-stone-gray uppercase mt-2">Flaschen</p>
                </div>
                <button onClick={() => setPurchaseQty(purchaseQty + 1)} className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-burgundy"><Plus className="w-6 h-6" /></button>
             </div>
             <div>
               <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Einstandspreis (€/Flasche)</label>
               <input 
                type="number" 
                value={purchasePrice} 
                onChange={e => setPurchasePrice(parseFloat(e.target.value))} 
                className="w-full bg-alabaster mt-2 px-8 py-5 rounded-2xl border-2 border-transparent focus:border-burgundy/20 focus:outline-none font-serif text-3xl font-bold text-charcoal"
               />
             </div>
             <button onClick={handleRegisterPurchase} className="w-full py-6 bg-burgundy text-white font-black rounded-2xl uppercase tracking-widest text-xs shadow-xl shadow-burgundy/20 hover:bg-burgundy-light">Abschließen</button>
           </div>
        </Modal>
      )}

      {isEditModalOpen && (
        <Modal title="Stammdaten Kuratieren" onClose={() => setIsEditModalOpen(false)}>
          <div className="p-4 bg-alabaster rounded-2xl text-center">
            <p className="text-stone-gray text-sm italic">Editor wird geladen...</p>
            <button onClick={() => setIsEditModalOpen(false)} className="mt-4 px-6 py-2 bg-burgundy text-white rounded-xl">Schließen</button>
          </div>
        </Modal>
      )}
    </div>
  );
};

const MetricCard = ({ label, value, icon: Icon }: any) => (
  <div className="bg-white p-6 rounded-2xl border border-burgundy/5 shadow-premium flex flex-col gap-3">
    <div className="p-2.5 bg-alabaster rounded-xl text-burgundy w-fit"><Icon className="w-4 h-4" /></div>
    <div>
      <p className="text-[9px] font-black text-stone-gray uppercase tracking-widest mb-1">{label}</p>
      <p className="text-sm font-bold text-charcoal truncate">{value || 'N/A'}</p>
    </div>
  </div>
);

const ContentCard = ({ title, icon: Icon, children }: any) => (
  <section className="bg-white rounded-[2.5rem] border border-burgundy/5 p-8 shadow-premium h-full">
    <div className="flex items-center gap-3 mb-6">
      <div className="p-2.5 bg-alabaster rounded-xl text-burgundy"><Icon className="w-4 h-4" /></div>
      <h3 className="font-serif text-xl font-bold text-charcoal">{title}</h3>
    </div>
    {children}
  </section>
);

const StructureRow = ({ label, value }: { label: string, value?: number }) => (
  <div className="space-y-1.5">
    <div className="flex justify-between items-center px-1">
      <span className="text-[10px] font-black uppercase tracking-widest text-stone-gray">{label}</span>
      <span className="text-[10px] font-bold text-burgundy">{value ? `${value}/5` : 'N/A'}</span>
    </div>
    <div className="h-2 bg-alabaster rounded-full overflow-hidden flex gap-1 p-0.5">
       {[1,2,3,4,5].map(i => (
         <div key={i} className={`flex-1 rounded-full ${value && value >= i ? 'bg-burgundy' : 'bg-white'}`} />
       ))}
    </div>
  </div>
);

const DataRow = ({ label, value, highlight }: any) => (
  <div className={`flex justify-between items-center py-2 border-b border-alabaster last:border-0 ${highlight ? 'bg-gold/5 -mx-2 px-2 rounded-lg' : ''}`}>
    <span className="text-[10px] font-black uppercase tracking-widest text-stone-gray">{label}</span>
    <span className={`text-sm font-medium ${highlight ? 'text-gold-dim font-bold' : 'text-charcoal'}`}>{value || '—'}</span>
  </div>
);

const TechItem = ({ icon: Icon, label, value }: any) => (
  <div className="flex gap-4 group">
    <div className="p-3 bg-alabaster rounded-2xl text-stone-gray h-fit"><Icon className="w-5 h-5" /></div>
    <div>
      <p className="text-[9px] font-black uppercase text-stone-gray tracking-widest mb-1">{label}</p>
      <p className="text-sm font-medium text-charcoal">{value || 'K.A.'}</p>
    </div>
  </div>
);

const Modal = ({ title, onClose, children }: any) => (
  <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-charcoal/40 backdrop-blur-md animate-in fade-in duration-300">
    <div className="bg-white w-full max-w-xl rounded-[3rem] shadow-2xl border border-burgundy/5 overflow-hidden flex flex-col">
      <div className="p-8 border-b border-alabaster flex justify-between items-center bg-alabaster/30">
        <h3 className="font-serif text-2xl font-bold text-charcoal">{title}</h3>
        <button onClick={onClose} className="p-2 hover:bg-white rounded-full"><X className="w-6 h-6 text-stone-gray" /></button>
      </div>
      <div className="p-10 overflow-y-auto max-h-[70vh]">
        {children}
      </div>
    </div>
  </div>
);

const EmptyText = ({ children }: any) => <p className="text-xs text-stone-gray italic py-4">{children}</p>;
