
import React, { useState, useEffect, useMemo } from 'react';
import { Wine, Occasion, OccasionInstance, RepeatRule } from '../types.ts';
import { storageService } from '../services/storage.ts';
import { 
  CalendarDays, Plus, Trash2, Wine as WineIcon, 
  X, Sparkles, GlassWater, Calendar, ArrowRight, 
  CheckCircle2, Search, Filter, Layers, Clock, Settings
} from 'lucide-react';

export const EnjoymentPlan: React.FC = () => {
  const [instances, setInstances] = useState<OccasionInstance[]>([]);
  const [wines, setWines] = useState<Wine[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  // Form State
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [repeatRule, setRepeatRule] = useState<RepeatRule>('none');
  const [repeatInterval, setRepeatInterval] = useState(1);

  // Loading Logic
  const loadData = async () => {
    setLoading(true);
    const [instData, wineData] = await Promise.all([
      storageService.getOccasionInstances(),
      storageService.getWines()
    ]);
    setInstances(instData);
    setWines(wineData.filter(w => !w.wishlist && w.quantity > 0));
    setLoading(false);
  };

  useEffect(() => { loadData(); }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !startDate) return;

    try {
      await storageService.saveOccasion({
        title,
        start_date: startDate,
        end_date: repeatRule === 'none' ? startDate : endDate,
        repeat_rule: repeatRule,
        repeat_interval: repeatInterval
      });
      setShowForm(false);
      resetForm();
      await loadData();
    } catch (err) {
      alert("Fehler beim Planen der Serie.");
    }
  };

  const resetForm = () => {
    setTitle(''); setStartDate(''); setEndDate('');
    setRepeatRule('none'); setRepeatInterval(1);
  };

  const handleAssignWine = async (instanceId: string, wineId: string | null) => {
    await storageService.updateInstanceWine(instanceId, wineId);
    setInstances(prev => prev.map(inst => 
      inst.id === instanceId ? { ...inst, wine_id: wineId } : inst
    ));
  };

  const handleStatusToggle = async (inst: OccasionInstance) => {
    const nextStatus = inst.status === 'planned' ? 'consumed' : 'planned';
    await storageService.updateInstanceStatus(inst.id, nextStatus);
    setInstances(prev => prev.map(i => 
      i.id === inst.id ? { ...i, status: nextStatus as any } : i
    ));
  };

  const handleDeleteSeries = async (occId: string) => {
    if (!window.confirm("Ganze Serie und alle zugehörigen Termine löschen?")) return;
    await storageService.deleteOccasion(occId);
    await loadData();
  };

  const futureInstances = useMemo(() => {
    return instances.filter(i => new Date(i.instance_date) >= new Date(new Date().setHours(0,0,0,0)));
  }, [instances]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div className="flex flex-col gap-2">
          <h2 className="font-serif text-4xl font-bold text-charcoal">Anlass-Planung</h2>
          <p className="text-stone-gray font-medium tracking-wide">
            Verwalten Sie Ihre Verkostungs-Termine und weisen Sie edle Tropfen zu.
          </p>
        </div>
        
        <button 
          onClick={() => setShowForm(!showForm)}
          className="flex items-center gap-2 px-6 py-3 bg-burgundy hover:bg-burgundy-light text-white font-black rounded-xl transition-all shadow-premium uppercase tracking-wider text-sm"
        >
          {showForm ? <X className="w-5 h-5" /> : <Plus className="w-5 h-5" />}
          <span>{showForm ? 'Abbrechen' : 'Serie planen'}</span>
        </button>
      </header>

      {showForm && (
        <section className="bg-white border border-burgundy/10 p-10 rounded-[2.5rem] shadow-premium animate-in slide-in-from-top-4 duration-500">
          <div className="flex items-center gap-3 mb-10">
            <Sparkles className="text-gold w-6 h-6" />
            <h3 className="font-serif text-3xl font-bold text-charcoal">Event-Serie konfigurieren</h3>
          </div>
          <form onSubmit={handleSubmit} className="space-y-8">
            <div className="space-y-2">
              <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Titel der Serie</label>
              <input 
                type="text" value={title} onChange={(e) => setTitle(e.target.value)}
                placeholder="z.B. Monatliche Raritätenprobe"
                className="w-full px-6 py-4 bg-alabaster border border-burgundy/5 rounded-2xl focus:outline-none focus:border-burgundy/30 font-medium"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Startdatum</label>
                <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-full px-6 py-4 bg-alabaster border border-burgundy/5 rounded-2xl" required />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Enddatum</label>
                <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} disabled={repeatRule === 'none'} className="w-full px-6 py-4 bg-alabaster border border-burgundy/5 rounded-2xl disabled:opacity-30" />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Wiederholung</label>
                <select value={repeatRule} onChange={(e) => setRepeatRule(e.target.value as RepeatRule)} className="w-full px-6 py-4 bg-alabaster border border-burgundy/5 rounded-2xl font-bold">
                  <option value="none">Keine (Einmalig)</option>
                  <option value="daily">Täglich</option>
                  <option value="weekly">Wöchentlich</option>
                  <option value="monthly">Monatlich</option>
                  <option value="yearly">Jährlich</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black uppercase tracking-widest text-stone-gray ml-2">Intervall (Jede X-te Einheit)</label>
                <input type="number" min="1" value={repeatInterval} onChange={(e) => setRepeatInterval(parseInt(e.target.value))} className="w-full px-6 py-4 bg-alabaster border border-burgundy/5 rounded-2xl font-bold" />
              </div>
            </div>

            <button type="submit" className="w-full py-5 bg-gold text-white font-black rounded-2xl shadow-xl hover:bg-gold-bright transition-all flex items-center justify-center gap-3 uppercase tracking-[0.2em] text-xs">
              <span>Termine in Zeitkapsel generieren</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </form>
        </section>
      )}

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Clock className="w-12 h-12 text-burgundy animate-spin" />
          <p className="text-[10px] font-black uppercase tracking-widest text-stone-gray">Lade Termin-Instanzen...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-40">
          {futureInstances.length > 0 ? (
            futureInstances.map(inst => (
              <InstanceCard 
                key={inst.id} 
                instance={inst} 
                wines={wines}
                onAssign={handleAssignWine}
                onToggleStatus={handleStatusToggle}
                onDeleteSeries={handleDeleteSeries}
              />
            ))
          ) : (
            <div className="col-span-full flex flex-col items-center justify-center py-32 bg-white rounded-[3rem] border-2 border-dashed border-burgundy/10 shadow-premium">
              <CalendarDays className="w-20 h-20 text-burgundy/10 mb-6" />
              <h3 className="text-2xl font-serif text-charcoal mb-2">Noch keine Pläne geschmiedet</h3>
              <p className="text-stone-gray text-sm max-w-sm text-center px-8">Erstellen Sie Ihre erste Event-Serie, um Weine für die Zukunft zu reservieren.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

const InstanceCard = ({ instance, wines, onAssign, onToggleStatus, onDeleteSeries }: any) => {
  const [isAssigning, setIsAssigning] = useState(false);
  const selectedWine = wines.find((w: any) => w.id === instance.wine_id);
  const isConsumed = instance.status === 'consumed';

  return (
    <div className={`
      relative group bg-white p-8 rounded-[2.5rem] border transition-all duration-500 flex flex-col h-full shadow-premium
      ${isConsumed ? 'opacity-50 grayscale' : 'hover:scale-[1.02] border-burgundy/5'}
      ${selectedWine && !isConsumed ? 'border-gold/30 ring-1 ring-gold/10' : ''}
    `}>
      <div className="flex justify-between items-start mb-6">
        <div>
          <p className="text-[10px] font-black text-burgundy uppercase tracking-[0.2em] mb-1">
            {new Date(instance.instance_date).toLocaleDateString('de-DE', { day: '2-digit', month: 'long' })}
          </p>
          <p className="text-xs font-bold text-stone-gray uppercase tracking-widest">
            {new Date(instance.instance_date).getFullYear()}
          </p>
        </div>
        <button 
          onClick={() => onDeleteSeries(instance.occasion_id)}
          className="p-2 text-stone-gray/20 hover:text-red-500 transition-colors"
          title="Gesamte Serie löschen"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      <h4 className="font-serif text-2xl font-bold text-charcoal leading-tight mb-8">
        {instance.occasion?.title}
      </h4>

      <div className="flex-1 space-y-4 mb-8">
        <div className={`p-5 rounded-2xl border transition-all flex items-center gap-4
          ${selectedWine ? 'bg-gold/5 border-gold/20' : 'bg-alabaster border-burgundy/5'}
        `}>
          <div className={`p-2 rounded-lg ${selectedWine ? 'text-gold' : 'text-stone-gray/30'}`}>
            <WineIcon className="w-5 h-5" />
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-[8px] font-black uppercase tracking-widest text-stone-gray mb-0.5">Reservierter Wein</p>
            {selectedWine ? (
              <p className="text-sm font-bold text-charcoal truncate">
                <span className="text-burgundy opacity-70">{selectedWine.vintage}</span> {selectedWine.name}
              </p>
            ) : (
              <p className="text-sm font-medium text-stone-gray/50 italic">Keine Zuweisung</p>
            )}
          </div>
          {selectedWine && (
            <button onClick={() => onAssign(instance.id, null)} className="p-1.5 hover:bg-white rounded-lg transition-colors text-stone-gray">
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {isAssigning ? (
          <div className="space-y-2 animate-in slide-in-from-top-2">
            <select 
              autoFocus
              className="w-full px-4 py-3 bg-white border border-burgundy/20 rounded-xl text-xs font-bold focus:outline-none"
              onChange={(e) => { onAssign(instance.id, e.target.value); setIsAssigning(false); }}
              onBlur={() => setIsAssigning(false)}
            >
              <option value="">Wein wählen...</option>
              {wines.map((w: any) => (
                <option key={w.id} value={w.id}>{w.vintage} {w.name} ({w.quantity} Fl.)</option>
              ))}
            </select>
          </div>
        ) : (
          !selectedWine && !isConsumed && (
            <button 
              onClick={() => setIsAssigning(true)}
              className="w-full py-3 bg-white border-2 border-dashed border-burgundy/10 hover:border-burgundy/30 text-burgundy text-[10px] font-black rounded-xl uppercase tracking-widest transition-all flex items-center justify-center gap-2"
            >
              <Plus className="w-3 h-3" /> Zuweisen
            </button>
          )
        )}
      </div>

      <div className="flex items-center justify-between pt-6 border-t border-alabaster">
        <div className={`flex items-center gap-2 text-[9px] font-black uppercase tracking-widest
          ${isConsumed ? 'text-sage' : 'text-stone-gray/40'}
        `}>
          <CheckCircle2 className="w-4 h-4" />
          {isConsumed ? 'Genossen' : 'Geplant'}
        </div>
        <button 
          onClick={() => onToggleStatus(instance)}
          className={`px-4 py-2 rounded-lg text-[9px] font-black uppercase tracking-widest transition-all
            ${isConsumed ? 'bg-alabaster text-stone-gray' : 'bg-burgundy text-white hover:bg-burgundy-light shadow-lg'}
          `}
        >
          {isConsumed ? 'Reaktivieren' : 'Getrunken'}
        </button>
      </div>
    </div>
  );
};
