
import { createClient } from '@supabase/supabase-js';

const getEnv = (key: string) => {
  try {
    // Check for process.env (Node/Shimmed standard)
    if (typeof process !== 'undefined' && process.env && process.env[key]) {
      return process.env[key];
    }
    
    // Fallback for Vite-like meta env if it exists
    // @ts-ignore
    if (typeof import.meta !== 'undefined' && import.meta.env && import.meta.env[key]) {
      // @ts-ignore
      return import.meta.env[key];
    }
  } catch (e) {
    // Ignore errors
  }
  return '';
};

const supabaseUrl = getEnv('VITE_SUPABASE_URL') || 'https://etuxsbqllgmiioamfvah.supabase.co';
const supabaseAnonKey = getEnv('VITE_SUPABASE_ANON_KEY') || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImV0dXhzYnFsbGdtaWlvYW1mdmFoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAxMDgwOTQsImV4cCI6MjA4NTY4NDA5NH0.hGSa_YCWXqbrWWEWFEBOPAXHYNStF9I0luC-oaYYIls';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
