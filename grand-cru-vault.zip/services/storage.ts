
import { Wine, Tasting, Occasion, OccasionInstance, RepeatRule } from '../types.ts';
import { PRE_SEED_WINES } from '../constants.ts';
import { supabase } from './supabase.ts';

/**
 * Grundlegende Hilfsmethoden für den lokalen Speicher (ESM kompatibel)
 */
export const getItem = (key: string) => localStorage.getItem(key);
export const setItem = (key: string, value: string) => localStorage.setItem(key, value);
export const removeItem = (key: string) => localStorage.removeItem(key);

export const storageService = {
  // --- AUTHENTIFIZIERUNG ---
  getCurrentUser: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;
    return { 
      id: user.id, 
      email: user.email || '', 
      currency: 'EUR', 
      target_date: '2044-12-31' 
    };
  },

  logout: async () => { 
    await supabase.auth.signOut(); 
    window.location.reload(); 
  },

  signUp: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) throw error;
    return data.user;
  },

  signIn: async (email: string, password: string) => {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
    return data.user;
  },

  signInAnonymously: async () => {
    const { data, error } = await supabase.auth.signInAnonymously();
    if (error) throw error;
    if (data.user) await storageService.seedIfNewUser(data.user.id);
    return data.user;
  },

  seedIfNewUser: async (userId: string) => {
    const { count } = await supabase.from('wines').select('*', { count: 'exact', head: true }).eq('user_id', userId);
    if (count === 0) {
      const seeded = PRE_SEED_WINES.map(w => ({ 
        ...w, 
        user_id: userId, 
        created_at: new Date().toISOString(), 
        updated_at: new Date().toISOString() 
      }));
      await supabase.from('wines').insert(seeded);
    }
  },

  // --- WEINBESTAND ---
  getWines: async (): Promise<Wine[]> => {
    const { data, error } = await supabase
      .from('wines')
      .select('*')
      .is('deleted_at', null)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data as Wine[]) || [];
  },

  getWineById: async (id: string): Promise<Wine | null> => {
    const { data } = await supabase.from('wines').select('*').eq('id', id).single();
    return data as Wine;
  },

  saveWine: async (wine: Partial<Wine>): Promise<Wine> => {
    const { data: { user } } = await supabase.auth.getUser();
    const payload = { ...wine, user_id: user?.id, updated_at: new Date().toISOString() };
    const { data, error } = wine.id 
      ? await supabase.from('wines').update(payload).eq('id', wine.id).select().single()
      : await supabase.from('wines').insert([{ ...payload, created_at: new Date().toISOString() }]).select().single();
    if (error) throw error;
    return data as Wine;
  },

  adjustStock: async (id: string, delta: number, context?: string) => {
    const { data: wine } = await supabase.from('wines').select('quantity').eq('id', id).single();
    if (!wine) return null;
    const { data } = await supabase.from('wines').update({ 
      quantity: Math.max(0, wine.quantity + delta), 
      updated_at: new Date().toISOString() 
    }).eq('id', id).select().single();
    return data;
  },

  recordPurchase: async (purchase: { wine_id: string; quantity: number; price_per_bottle: number; date: string }) => {
    const { data: wine } = await supabase.from('wines').select('*').eq('id', purchase.wine_id).single();
    if (!wine) return null;
    const newQuantity = wine.quantity + purchase.quantity;
    const newPrice = ((wine.purchase_price * wine.quantity) + (purchase.price_per_bottle * purchase.quantity)) / (newQuantity || 1);
    const { data, error } = await supabase.from('wines').update({ 
      quantity: newQuantity, 
      purchase_price: newPrice,
      updated_at: new Date().toISOString() 
    }).eq('id', purchase.wine_id).select().single();
    if (error) throw error;
    return data as Wine;
  },

  // --- SOFT DELETE & PAPIERKORB ---
  softDeleteWine: async (id: string, reason: string) => {
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('wines').update({ 
      deleted_at: new Date().toISOString(), 
      deleted_reason: reason,
      updated_at: new Date().toISOString() 
    }).eq('id', id);
    if (error) throw error;
  },

  getDeletedWines: async (): Promise<Wine[]> => {
    const { data, error } = await supabase
      .from('wines')
      .select('*')
      .not('deleted_at', 'is', null)
      .order('deleted_at', { ascending: false });
    if (error) throw error;
    return (data as Wine[]) || [];
  },

  restoreWine: async (id: string) => {
    const { error } = await supabase.from('wines').update({ 
      deleted_at: null, 
      deleted_reason: null,
      updated_at: new Date().toISOString() 
    }).eq('id', id);
    if (error) throw error;
  },

  permanentlyDeleteWine: async (id: string) => {
    const { error } = await supabase.from('wines').delete().eq('id', id);
    if (error) throw error;
  },

  // --- EVENTS & TASTINGS ---
  getOccasionInstances: async (): Promise<OccasionInstance[]> => {
    const { data } = await supabase.from('occasion_instances').select('*, occasion:occasions(*)').order('instance_date', { ascending: true });
    return (data as any[]) || [];
  },

  updateInstanceWine: async (instanceId: string, wineId: string | null) => {
    await supabase.from('occasion_instances').update({ wine_id: wineId, updated_at: new Date().toISOString() }).eq('id', instanceId);
  },

  updateInstanceStatus: async (instanceId: string, status: string) => {
    await supabase.from('occasion_instances').update({ status: status, updated_at: new Date().toISOString() }).eq('id', instanceId);
  },

  saveOccasion: async (occ: Partial<Occasion>): Promise<Occasion> => {
    const { data: { user } } = await supabase.auth.getUser();
    const payload = { ...occ, user_id: user?.id };
    const { data, error } = occ.id 
      ? await supabase.from('occasions').update(payload).eq('id', occ.id).select().single()
      : await supabase.from('occasions').insert([payload]).select().single();
    if (error) throw error;
    const savedOcc = data as Occasion;
    await storageService.syncInstances(savedOcc);
    return savedOcc;
  },

  deleteOccasion: async (id: string) => {
    await supabase.from('occasions').delete().eq('id', id);
  },

  syncInstances: async (occ: Occasion) => {
    const dates = storageService.generateDates(occ.start_date, occ.end_date, occ.repeat_rule, occ.repeat_interval);
    const instances = dates.map(date => ({
      occasion_id: occ.id,
      user_id: occ.user_id,
      instance_date: date,
      status: 'planned'
    }));
    await supabase.from('occasion_instances').upsert(instances, { onConflict: 'user_id, occasion_id, instance_date', ignoreDuplicates: true });
  },

  generateDates: (start: string, end: string, rule: RepeatRule, interval: number): string[] => {
    const dates: string[] = [];
    const startDate = new Date(start);
    const endDate = new Date(end);
    let current = new Date(startDate);
    if (rule === 'none') return [start];
    while (current <= endDate) {
      dates.push(current.toISOString().split('T')[0]);
      if (rule === 'daily') current.setDate(current.getDate() + interval);
      else if (rule === 'weekly') current.setDate(current.getDate() + (7 * interval));
      else if (rule === 'monthly') current.setMonth(current.getMonth() + interval);
      else if (rule === 'yearly') current.setFullYear(current.getFullYear() + interval);
      if (dates.length > 365) break; 
    }
    return dates;
  },

  getTastings: async (wineId: string): Promise<Tasting[]> => {
    const { data } = await supabase.from('tastings').select('*').eq('wine_id', wineId).order('date', { ascending: false });
    return (data as Tasting[]) || [];
  },

  addTasting: async (tasting: Partial<Tasting>): Promise<Tasting> => {
    const { data: { user } } = await supabase.auth.getUser();
    const { data, error } = await supabase.from('tastings').insert([{ ...tasting, user_id: user?.id, date: new Date().toISOString() }]).select().single();
    if (error) throw error;
    await storageService.adjustStock(tasting.wine_id!, -1);
    return data as Tasting;
  }
};
