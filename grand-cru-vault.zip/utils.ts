
import { Wine, WineStatus, PortfolioStats, DrinkArchetype } from './types.ts';

export const getWineStatus = (wine: Wine): WineStatus => {
  const currentYear = new Date().getFullYear();
  if (currentYear < wine.drink_start) return WineStatus.HOLD;
  if (currentYear > wine.drink_end) return WineStatus.PAST_PEAK;
  return WineStatus.READY;
};

export const calculatePortfolioStats = (wines: Wine[]): PortfolioStats => {
  const currentYear = new Date().getFullYear();
  
  const inventory = wines.filter(w => !w.wishlist);
  
  const stats = inventory.reduce((acc, wine) => {
    acc.totalBottles += wine.quantity;
    acc.totalValue += wine.purchase_price * wine.quantity;
    
    if (wine.category === 'Investment') {
      acc.investmentValue += wine.purchase_price * wine.quantity;
    }
    
    const status = getWineStatus(wine);
    if (status === WineStatus.READY) acc.readyCount++;
    else if (status === WineStatus.HOLD) acc.holdCount++;
    else if (status === WineStatus.PAST_PEAK) acc.pastPeakCount++;
    
    acc.totalVintages += wine.vintage;
    
    return acc;
  }, {
    totalBottles: 0,
    totalValue: 0,
    readyCount: 0,
    holdCount: 0,
    pastPeakCount: 0,
    investmentValue: 0,
    totalVintages: 0
  });

  const averageAge = inventory.length > 0 ? currentYear - (stats.totalVintages / inventory.length) : 0;

  return {
    totalBottles: stats.totalBottles,
    totalValue: stats.totalValue,
    readyCount: stats.readyCount,
    holdCount: stats.holdCount,
    pastPeakCount: stats.pastPeakCount,
    averageAge: Math.round(averageAge),
    investmentValue: stats.investmentValue
  };
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('de-DE', { style: 'currency', currency: 'EUR' }).format(amount);
};

// --- OENOLOGICAL INTELLIGENCE (Non-AI Logic) ---

export const DRINK_ARCHETYPES: Record<string, number[]> = {
  EARLY: [10, 25, 45, 70, 90, 100, 95, 80, 60, 40, 25, 15],
  CLASSIC: [10, 20, 35, 55, 75, 90, 100, 100, 90, 75, 55, 35],
  LONG_LIVED: [5, 10, 18, 28, 40, 55, 70, 85, 95, 100, 95, 85],
  SWEET: [15, 25, 40, 55, 70, 82, 92, 100, 100, 98, 95, 92]
};

export interface DrinkabilityResult {
  score: number;
  status: string;
  wu: number; // Used Window fraction 0..1
}

export const calculateDrinkability = (wine: Wine): DrinkabilityResult => {
  if (!wine.drink_start || !wine.drink_end) {
    return { score: 0, status: 'Unbekannt', wu: 0 };
  }
  
  const currentYear = new Date().getFullYear();
  
  if (currentYear < wine.drink_start) {
    return { score: 10, status: 'Zu früh', wu: 0 };
  }
  
  if (currentYear > wine.drink_end) {
    return { score: 40, status: 'Über Fenster', wu: 1 };
  }
  
  const duration = wine.drink_end - wine.drink_start;
  // Handle single year window
  const progress = duration === 0 ? 1 : (currentYear - wine.drink_start) / duration;
  
  // 12 Segments (0 to 11)
  const segmentIndex = Math.min(11, Math.floor(progress * 12));
  
  // Determine Archetype Rule-Based
  let archetype: string = wine.drink_archetype || 'CLASSIC';
  
  if (!wine.drink_archetype) {
     if (wine.wine_type === 'Rosé' || wine.wine_type === 'Weiß') {
       archetype = 'EARLY';
       // Exception: Complex Whites
       if (wine.region?.includes('Burgund') || wine.region?.includes('Mosel')) archetype = 'CLASSIC';
     } else if (wine.category === 'Investment' || wine.region?.includes('Bordeaux') || wine.region?.includes('Barolo')) {
       archetype = 'LONG_LIVED';
     } else if (wine.wine_type === 'Süßwein') {
       archetype = 'SWEET';
     }
  }
  
  const weights = DRINK_ARCHETYPES[archetype] || DRINK_ARCHETYPES['CLASSIC'];
  const score = weights[segmentIndex] || 0;
  
  let status = 'Trinkreif';
  if (score > 85) status = 'Optimal';
  else if (score < 60) status = 'Anlaufphase';
  
  return { score, status, wu: progress };
};

// --- ERROR HANDLING ---

export const handleAiOperationError = (error: any) => {
  console.error("AI Operation failed:", error);
  
  let isQuota = false;
  const errorStr = JSON.stringify(error);
  
  if (
    errorStr.includes('429') || 
    errorStr.includes('RESOURCE_EXHAUSTED') || 
    error?.status === 429 ||
    error?.error?.code === 429
  ) {
    isQuota = true;
  }

  if (isQuota) {
    alert("⚠️ KI-Limit erreicht (Quota Exceeded)\n\nIhr kostenloses Kontingent für AI-Analysen ist erschöpft. Bitte versuchen Sie es später erneut oder tragen Sie die Daten manuell ein.");
  } else {
    alert("Verbindung fehlgeschlagen. Bitte überprüfen Sie Ihre Internetverbindung.");
  }
};
